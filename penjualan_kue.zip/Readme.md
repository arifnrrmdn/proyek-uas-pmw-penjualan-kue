## TUGAS UAS PMW

![image](https://github.com/arifnrrmdn/uas-pmw/assets/91766087/8d7c54de-d79a-4234-a403-33c529ea0fbd)
