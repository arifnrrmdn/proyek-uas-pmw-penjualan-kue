<?php
  $koneksi = mysqli_connect('localhost', 'root', '', 'penjualan_kue');
?>